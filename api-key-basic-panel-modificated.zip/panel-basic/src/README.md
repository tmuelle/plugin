<!-- This README file is going to be the one displayed on the Grafana.com website for your plugin -->

# Basic Panel

Showcase how to build a basic panel plugin
