export const ariaLabels = {
  gradientScheme: 'Panel scheme gradient',
  gradientHue: 'Panel hue gradient',
  gradientOpacity: 'Panel opacity gradient',
  gradientNone: 'Panel no gradient',
  fillOpacity: 'Fill opacity',
  legendDisplayList: 'Legend display list',
  legendDisplayTable: 'Legend display table',
  legendDisplayHidden: 'Legend hidden',
  legendPlacementBottom: 'Legend placement bottom',
  legendPlacementRight: 'Legend placement right',
};
