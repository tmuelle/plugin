export { SimplePanel } from './SimplePanel/SimplePanel';
