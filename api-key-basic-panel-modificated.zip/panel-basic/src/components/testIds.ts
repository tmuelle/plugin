export const testIds = {
  panel: {
    container: 'data-testid panel-container',
  },
};
