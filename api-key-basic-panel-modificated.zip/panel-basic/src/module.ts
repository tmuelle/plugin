import { PanelPlugin, FieldColorModeId} from '@grafana/data';
//import { LegendDisplayMode, GraphGradientMode } from '@grafana/schema';
import { SimpleOptions } from './types';
import { SimplePanel } from './components';
//import { ariaLabels } from './components/ariaLabels';
//import { random } from 'lodash';



export const plugin = new PanelPlugin<SimpleOptions>(SimplePanel)
  .useFieldConfig({
    // Field config...
    standardOptions: {
      color: {
        defaultValue: {
          mode: FieldColorModeId.ContinuousGrYlRd,
        },
      },
    },
  })
  .setPanelOptions((builder) => {
    // Panel options...

    // Add a function to generate a random string
    const generateRandomString = () => {
      return Array(10 + 1).join((Math.random().toString(36) + '00000000000000000').slice(2, 18)).slice(0, 10);
    };

    // Update the text input field with the generated random string
    builder.addTextInput({
      path: 'text',
      name: 'Random Text',
      description: 'Kopiere die Buchstabenfolge im folgenden Feld.',
      defaultValue: generateRandomString(),
    });

    // Add other panel options as needed...

    return builder;
  });




/* export const plugin = new PanelPlugin<SimpleOptions>(SimplePanel)
  .useFieldConfig({
    
    useCustomConfig: (builder) => {
      builder
      //.addCustomEditor({
        
      //})
      .addTextInput({
        path: 'text',
        name: Array(10+1).join((Math.random().toString(36)+'00000000000000000').slice(2, 18)).slice(0, 10),
        description: 'Kopiere die Buchstabenfolge im folgenden Feld.',
        defaultValue: Array(10+1).join((Math.random().toString(36)+'00000000000000000').slice(2, 18)).slice(0, 10),
      }) 
      .addRadio({
          path: 'gradientMode',
          name: 'Gradient mode',
          defaultValue: GraphGradientMode.Scheme,
          settings: {
            options: [
              {
                label: 'None',
                value: GraphGradientMode.None,
                ariaLabel: ariaLabels.gradientNone,
              },
              {
                label: 'Opacity',
                value: GraphGradientMode.Opacity,
                description: 'Enable fill opacity gradient',
                ariaLabel: ariaLabels.gradientOpacity,
              },
              {
                label: 'Hue',
                value: GraphGradientMode.Hue,
                description: 'Small color hue gradient',
                ariaLabel: ariaLabels.gradientHue,
              },
              {
                label: 'Scheme',
                value: GraphGradientMode.Scheme,
                description: 'Use color scheme to define gradient',
                ariaLabel: ariaLabels.gradientScheme,
              },
            ],
          },
        })
        .addSliderInput({
          path: 'fillOpacity',
          name: 'Fill opacity',
          defaultValue: 25,
          settings: {
            min: 1,
            max: 100,
            step: 1,
            ariaLabelForHandle: ariaLabels.fillOpacity,
          },
        })
        

        .addSliderInput({
          path: 'ApiKey',
          name: 'APIKey Generator',
          defaultValue: 25,
          settings: {
            min: 1000000000,
            max: 9999999999,
            step: random()*9999999999,
            ariaLabelForHandle: ariaLabels.fillOpacity,
          },
        });
    },
  })
  .setPanelOptions((builder) => {
    return builder
      .addRadio({
        path: 'legend.displayMode',
        name: 'Legend mode',
        category: ['Legend'],
        description: '',
        defaultValue: LegendDisplayMode.List,
        settings: {
          options: [
            {
              value: LegendDisplayMode.List,
              label: 'List',
              ariaLabel: ariaLabels.legendDisplayList,
            },
            {
              value: LegendDisplayMode.Table,
              label: 'Table',
              ariaLabel: ariaLabels.legendDisplayTable,
            },
            {
              value: undefined,
              label: 'Hidden',
              ariaLabel: ariaLabels.legendDisplayHidden,
            },
          ],
        },
      })
      .addRadio({
        path: 'legend.placement',
        name: 'Legend placement',
        category: ['Legend'],
        description: '',
        defaultValue: 'bottom',
        settings: {
          options: [
            {
              value: 'bottom',
              label: 'Bottom',
              ariaLabel: ariaLabels.legendPlacementBottom,
            },
            {
              value: 'right',
              label: 'Right',
              ariaLabel: ariaLabels.legendPlacementRight,
            },
          ],
        },
        showIf: (config) => !!config.legend.displayMode,
      });
  }); */
