import { VizLegendOptions } from '@grafana/schema';

export interface SimpleOptions {
  legend: VizLegendOptions;
}
